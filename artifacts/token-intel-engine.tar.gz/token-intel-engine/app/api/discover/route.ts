import { NextRequest, NextResponse } from 'next/server';
import { discoverTokens } from '@/lib/discovery';

export const dynamic = 'force-dynamic';
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const url = (body.url || '').trim();
    const text = (body.text || '').trim();

    if (!url) {
      return NextResponse.json({ error: 'url is required' }, { status: 400 });
    }

    const result = await discoverTokens(url, text || undefined);
    return NextResponse.json(result);
  } catch (e: any) {
    console.error('Discovery error', e);
    return NextResponse.json(
      { error: 'Internal discovery failure', detail: e.message },
      { status: 500 }
    );
  }
}
