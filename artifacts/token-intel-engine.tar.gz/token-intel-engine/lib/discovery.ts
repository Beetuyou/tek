/**
 * Token Discovery Engine
 * Orchestrates normalization → content analysis → candidate discovery → evidence → aggregation
 */

import { normalizeUrl, NormalizedUrl } from './url-normalizer';
import { searchDex, DexPair } from './adapters/dexscreener';
import { scoreCandidate, ScoredCandidate, TokenCandidate } from './evidence';

export interface DiscoveryResult {
  normalized: NormalizedUrl;
  candidates: ScoredCandidate[];
  extracted: {
    cas: string[];
    tickers: string[];
  };
  errors: string[];
  durationMs: number;
}

const CA_REGEX = {
  solana: /\b[1-9A-HJ-NP-Za-km-z]{32,44}\b/g,
  evm: /\b0x[a-fA-F0-9]{40}\b/g,
};
const TICKER_REGEX = /\$([A-Za-z]{2,10})\b/g;

function extractSignals(text: string) {
  const cas = [
    ...(text.match(CA_REGEX.solana) || []),
    ...(text.match(CA_REGEX.evm) || []),
  ];
  const tickers = Array.from(text.matchAll(TICKER_REGEX)).map(m => m[1]);
  return { cas: [...new Set(cas)], tickers: [...new Set(tickers)] };
}

function pairToCandidate(p: DexPair, source: string): TokenCandidate {
  return {
    address: p.baseToken.address,
    chain: p.chainId,
    symbol: p.baseToken.symbol,
    name: p.baseToken.name,
    source,
    liquidityUsd: p.liquidity?.usd,
    marketCap: p.marketCap,
    socials: p.info?.socials,
    imageUrl: p.info?.imageUrl,
    pairUrl: p.url,
  };
}

export async function discoverTokens(rawUrl: string, providedText?: string): Promise<DiscoveryResult> {
  const start = Date.now();
  const errors: string[] = [];
  const normalized = normalizeUrl(rawUrl);

  if (!normalized.isValid) {
    return {
      normalized,
      candidates: [],
      extracted: { cas: [], tickers: [] },
      errors: [normalized.error || 'Invalid URL'],
      durationMs: Date.now() - start,
    };
  }

  // In a full implementation this would call social content retrieval adapters
  // (X API, TikTok scraper, Instagram, etc.). For now we rely on provided text
  // + handle-based search, which is the reliable public path.
  const text = providedText || '';
  const extracted = extractSignals(text);

  const rawCandidates: TokenCandidate[] = [];
  const seen = new Set<string>();

  // 1. Direct CA lookups
  for (const ca of extracted.cas) {
    try {
      // Try common chains
      const chains = ca.startsWith('0x')
        ? ['ethereum', 'base', 'bsc', 'arbitrum']
        : ['solana'];
      for (const chain of chains) {
        const pairs = await searchDex(ca, 5);
        for (const p of pairs) {
          const key = `${p.chainId}:${p.baseToken.address}`;
          if (!seen.has(key)) {
            seen.add(key);
            rawCandidates.push(pairToCandidate(p, 'direct_ca'));
          }
        }
      }
    } catch (e: any) {
      errors.push(`CA lookup failed for ${ca}: ${e.message}`);
    }
  }

  // 2. Ticker searches
  for (const ticker of extracted.tickers) {
    try {
      const pairs = await searchDex(ticker, 8);
      for (const p of pairs) {
        const key = `${p.chainId}:${p.baseToken.address}`;
        if (!seen.has(key)) {
          seen.add(key);
          rawCandidates.push(pairToCandidate(p, `ticker_${ticker}`));
        }
      }
    } catch (e: any) {
      errors.push(`Ticker search failed for ${ticker}: ${e.message}`);
    }
  }

  // 3. Handle-based search (tokens that list this Twitter)
  if (normalized.handle) {
    try {
      const pairs = await searchDex(normalized.handle, 10);
      for (const p of pairs) {
        const key = `${p.chainId}:${p.baseToken.address}`;
        if (!seen.has(key)) {
          seen.add(key);
          rawCandidates.push(pairToCandidate(p, 'handle_search'));
        }
      }
    } catch (e: any) {
      errors.push(`Handle search failed: ${e.message}`);
    }
  }

  // Score
  const candidates = rawCandidates
    .map(c => scoreCandidate(c, {
      handle: normalized.handle,
      text,
      tickers: extracted.tickers,
      cas: extracted.cas,
    }))
    .filter(c => c.confidence > 0.15)
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, 15);

  return {
    normalized,
    candidates,
    extracted,
    errors,
    durationMs: Date.now() - start,
  };
}
